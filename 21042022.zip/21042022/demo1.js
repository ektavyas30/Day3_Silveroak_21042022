function externalalert(){
    alert("alert is done..");
}
function externalconfirm(){
    if(confirm("Are you want to confirm....??")){
        alert("YES");
    }
    else{
        alert("NO");
    }
}
function externalprompt(){
    var fName=prompt("Enter Firstname ..");
    var lName=prompt("Enter Lastname ..");
    alert(fName+" "+lName);
}